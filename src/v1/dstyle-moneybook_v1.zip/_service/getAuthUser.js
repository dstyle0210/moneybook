function getAuthUser(uid){
    if(uid=="0MwBoXosqATbp9Dlu7e7KTNdaeJ3"){
        return "마봉아빠";
    }else if(uid=="zZn2t36Bu7Zm4fBMcK9N3yCPKBE3"){
        return "마봉엄마";
    };
    return null;
};