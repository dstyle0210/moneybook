function getTagCode(tag){ 
    if(tag=="고정"){return "f"};
    if(tag=="필수"){return "r"};
    if(tag=="변동"){return "c"};
    if(tag=="기타"){return "o"};
    if(tag=="용돈"){return "b"};
};